local map = vim.api.nvim_set_keymap
local default_opts = { noremap = true, silent = true }

-- включение сохранение по ctrl+s --
-- map('n', '<C-s>', ':w<CR>', default_opts)
-- map('i', '<C-s>', ':w<CR>', default_opts)
