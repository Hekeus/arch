vim.cmd [[packadd packer.nvim]]

return require('packer').startup(function(use)
  use 'wbthomason/packer.nvim'

	use { 'catppuccin/nvim', as = 'catppuccin' }

	use 'powerman/vim-plugin-ruscmd'

	use 'nvim-lua/plenary.nvim'

	use 'hrsh7th/nvim-cmp'

	use 'nvim-telescope/telescope.nvim'

	use {
		'nvim-treesitter/nvim-treesitter',
		run = ':TSUpdate'
	}

require ('nvim-treesitter.configs').setup ({

	-- список языков для подсветки
	ensure_installed = { 'lua' , 'c', 'markdown', 'markdown_inline' },

	-- позволяет устанавливать парсеры асинхронно
	sync_install = false,

	-- автоматическая установка языков при входе в файл
	-- рекомендуется установливать в false, если локально не установлен tree-sitter
	auto_install = false,

	highlight = {
		enable = true,		-- включение подсветки
	},

})

	use({
		"epwalsh/obsidian.nvim",
		tag = "*",
		config = function()
			require("obsidian").setup({
				workspaces = {
					{
						name = "notes",
						path = "~/cloud/notes",
					},
				},
			})
		end,
	})
end)
