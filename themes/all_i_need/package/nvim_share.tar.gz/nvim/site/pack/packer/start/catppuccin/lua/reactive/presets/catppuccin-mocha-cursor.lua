local palette = require("catppuccin.palettes").get_palette "mocha"
local presets = require "catppuccin.utils.reactive"

return presets.cursor("catppuccin-mocha-cursor", palette)
