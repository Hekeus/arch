---
id: note_with_additional_metadata
aliases: []
tags: []
foo: bar
---

# Note with additional metadata
