local M = {
  refs = require "obsidian.completion.refs",
  tags = require "obsidian.completion.tags",
}

return M
