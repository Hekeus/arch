---
id: foo
aliases:
 - foo
 - Foo
tags: []
---

# foo

This is some content.
