local M = {}

function M.get()
	return {
		GrugFarResultsMatch = { link = "IncSearch" },
	}
end

return M
