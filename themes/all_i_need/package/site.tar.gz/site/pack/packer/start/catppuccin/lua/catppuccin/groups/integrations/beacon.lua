local M = {}

function M.get()
	return {
		Beacon = { bg = C.blue },
	}
end

return M
