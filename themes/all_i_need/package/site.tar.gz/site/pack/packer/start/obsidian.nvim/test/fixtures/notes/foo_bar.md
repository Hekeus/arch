---
id: foo
aliases:
  - foo
  - Foo
  - Foo Bar
tags: []
---

# foo

This is some content.
