return require "catppuccin.utils.barbecue" "macchiato"
