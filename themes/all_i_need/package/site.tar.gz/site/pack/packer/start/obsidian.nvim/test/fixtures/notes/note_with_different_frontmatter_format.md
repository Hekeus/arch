---
aliases: [Amanda Green, Detective Green, Mandy]
tags: []
---

# Detective
